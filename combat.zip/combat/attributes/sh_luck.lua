ATTRIBUTE.name = "Luck"
ATTRIBUTE.desc = "You'd be pretty lucky if this did anything."