ATTRIBUTE.name = "Perception"
ATTRIBUTE.desc = "Your character's ability to see hidden things."