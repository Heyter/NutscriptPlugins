ATTRIBUTE.name = "Fortitude"
ATTRIBUTE.desc = "Your character's willpower to stand against fear."