ATTRIBUTE.name = "Medical"
ATTRIBUTE.desc = "Your character's skill with medicine and medical techniques."